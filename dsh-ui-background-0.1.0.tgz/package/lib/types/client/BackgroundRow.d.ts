import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import { type BackgroundFill } from '../background-settings.ts';
import type { createBackgroundStore } from './background-store.ts';
/** 图片上传的结果（uploadImage 注入回调的返回）。 */
export interface UploadedBackground {
    /** 服务端落盘的绝对路径（已持久化）。 */
    path: string;
    /** 图片像素宽。 */
    width: number;
    /** 图片像素高。 */
    height: number;
    /** 按比例适配选定的填充方式。 */
    fill: BackgroundFill;
}
/** 注入的业务面：五个写操作 + 清除 + 上传。 */
export interface BackgroundRowInjected {
    /** 切换预设（'none' 或内置预设 id）。 */
    setPreset: (id: string) => void;
    /** 设置不透明度（0.05..1）。 */
    setOpacity: (value: number) => void;
    /** 设置模糊半径（0..32 px）。 */
    setBlur: (value: number) => void;
    /** 设置图片填充方式。 */
    setFill: (value: BackgroundFill) => void;
    /** 设置自定义图片绝对路径；空串清除图片。 */
    setImagePath: (path: string) => void;
    /** 一键清除背景（预设置 none、图片清空）。 */
    clear: () => void;
    /** 上传本地图片：完成上传、持久化与比例适配，返回结果供展示。 */
    uploadImage: (file: File) => Promise<UploadedBackground>;
}
/** 完整组件 props：运行时分享 + store 分享 + locale 座位 + 注入面。 */
export type BackgroundRowProps = PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createBackgroundStore>> & PropsLocale<'settings.background'> & BackgroundRowInjected;
/**
 * 渲染背景设置行。
 * @param props - 组合后的 slot props。
 * @returns 设置行元素树。
 */
export declare function BackgroundRow({ t, useStore, setPreset, setOpacity, setBlur, setFill, setImagePath, clear, uploadImage }: BackgroundRowProps): import("react").JSX.Element;
/** 供 apply 侧传递类型（无值导出则仅类型）。 */
export type { BackgroundRowProps as BackgroundRowComponentProps };
//# sourceMappingURL=BackgroundRow.d.ts.map