/**
 * 背景状态运行时：设置命名空间读写、revision 快照与订阅的单一事实源。
 *
 * 设计对齐 ui-theme 的 ThemeRuntime：
 * - 写操作只有 set* 一组入口，每个入口校验参数、经 host scope 持久化、发布快照；
 * - host 发布的变更经 adopt() 吸收（不写回），浏览器与其它标签页的写入得以同步；
 * - 发布时把快照投影给呈现器（DOM），并通知订阅者（UI store 同步用）。
 * 不持有 ctx：生命周期（host 订阅、卸载）由装配方（apply）负责。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-10
 */
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import { type BackgroundFill, type BackgroundSettings } from '../background-settings.ts';
import type { BackgroundPresenter } from './background-presenter.ts';
/** 一次发布的不可变状态快照（uSES 安全：变化之间引用稳定）。 */
export interface BackgroundSnapshot {
    /** 当前生效的设置。 */
    readonly settings: Readonly<BackgroundSettings>;
    /** 单调递增的变更计数。 */
    readonly revision: number;
}
/**
 * 背景设置的运行时。
 * @param host - 装配方 bind 的同名设置 scope。
 * @param presenter - 负责 DOM 投影的呈现器。
 */
export declare class BackgroundRuntime {
    private readonly host;
    private readonly presenter;
    /** 当前生效设置（adopt 或写操作后更新）。 */
    private settings;
    private revision;
    private snapshot;
    private readonly listeners;
    constructor(host: SettingsScope<BackgroundSettings>, presenter: BackgroundPresenter);
    /**
     * 读当前不可变快照（引用稳定，uSES 安全）。
     * @returns 当前快照。
     */
    getSnapshot(): BackgroundSnapshot;
    /**
     * 订阅快照变更。
     * @param listener - 每次发布后的回调。
     * @returns 取消订阅函数。
     */
    subscribe(listener: () => void): () => void;
    /**
     * 吸收 host 已接受的 section（不写回）。装配方在 host.subscribe 里调用。
     */
    adopt(): void;
    /**
     * 切换背景预设（唯一入口）。
     * @param id - 内置预设 id、'none'（清除）或 'custom'（由 setImagePath 使用）。
     * @throws 未知预设 id（非 none/custom、也不在预设表）。
     */
    setPreset(id: string): void;
    /**
     * 设置不透明度。
     * @param value - BACKGROUND_OPACITY_MIN..MAX 的有限值。
     * @throws 越界或非有限值。
     */
    setOpacity(value: number): void;
    /**
     * 设置背景模糊半径。
     * @param value - BACKGROUND_BLUR_MIN..MAX 的整数 px。
     * @throws 越界或非整数。
     */
    setBlur(value: number): void;
    /**
     * 设置图片填充方式。
     * @param value - 填充方式枚举之一。
     * @throws 未知枚举值。
     */
    setFill(value: BackgroundFill): void;
    /**
     * 设置自定义图片路径；非空时同时把 preset 置为 'custom'，空串仅清除图片。
     *
     * 与其它字段不同，这里**先持久化再发布**：自定义图片的背景 URL 需要服务端
     * asset 路由按已落盘的设置授权，若先发布再异步持久化，首帧图片请求会命中
     * 旧设置返回 404，背景图不加载（"点击没反应"）。等待 host.set 落定后再
     * 发布，首次请求即为有效授权。持久化失败则抛错且不产生半状态。
     * @param path - 本地图片绝对路径（trim 后存储）。
     * @returns 持久化与发布的完成信号（调用方 fire-and-forget 时用 void 包裹）。
     */
    setImagePath(path: string): Promise<void>;
    /** 发布新快照：投影到 DOM、递增 revision、通知订阅者。 */
    private publish;
}
//# sourceMappingURL=background-runtime.d.ts.map