/**
 * dsh-ui-background 设置的 schemastery schema（Node 半边专用）。
 *
 * 由宿主 settings 服务校验并补全默认值；浏览器半边只读取 schema 解析后的
 * 值（类型见 background-settings.ts），因此本文件不进入 client bundle。
 *
 * 键名刻意写显式字面量而非常量：schemastery z.object 对 computed key 的
 * 类型推断会退化成 index signature，导致 schema 类型与 BackgroundSettings
 * 无法对应（键名由 background-settings.ts 的 FIELD 常量文档约束）。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-10
 */
import z from '@deepseek-ai/schemastery';
import { type BackgroundSettings } from './background-settings.ts';
/**
 * 背景设置的持久化 schema。
 * - preset 用自由字符串而非枚举：允许预设表后续演进，未知值由运行时回退。
 * - imagePath 默认空串：settings 文档里字段始终存在且为 JSON 友好形状。
 */
export declare const BackgroundSettingsSchema: z<BackgroundSettings>;
//# sourceMappingURL=background-schema.d.ts.map