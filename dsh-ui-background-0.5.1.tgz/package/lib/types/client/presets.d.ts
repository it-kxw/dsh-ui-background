import type { BackgroundLocaleKey } from './locales.ts';
/** 一个内置背景预设。 */
export interface BackgroundPreset {
    /** 稳定 id，保存在设置文档的 preset 字段。 */
    id: string;
    /** 展示名 locale key（t('preset.aurora') 等）。 */
    labelKey: BackgroundLocaleKey;
    /** 浅色配色下的 CSS background-image 值。 */
    light: string;
    /** 深色配色下的 CSS background-image 值。 */
    dark: string;
}
/**
 * 内置渐变预设，按展示顺序排列（'none' 恒在循环首位，见 nextPresetId）。
 * 色板取与 DSH 中性色系一致的浅/深两端，避免任一配色下背景刺眼。
 */
export declare const BACKGROUND_PRESETS: readonly BackgroundPreset[];
/** 内置预设的 id 全集（不含 none/custom，它们不是可点击的表项）。 */
export declare const BACKGROUND_PRESET_IDS: readonly string[];
/**
 * 按 id 查预设；未知 id 返回 undefined（调用方回退到 none）。
 * @param id - 设置的 preset 字段值。
 * @returns 匹配的预设，或 undefined。
 */
export declare function presetById(id: string): BackgroundPreset | undefined;
/**
 * 悬浮按钮的循环切换：'none' → 第一个预设 → … → 最后一个 → 'none'。
 * 当前值不在循环列表（自定义图片 'custom'、必应壁纸 'bing'）时重置到 'none'，
 * 保证按钮语义可预期（先关掉再选择；也避免一键切换触发网络请求）。
 * @param currentId - 当前设置的 preset 字段值。
 * @returns 下一个 preset 字段值。
 */
export declare function nextPresetId(currentId: string): string;
/** 当前值是否为自定义图片预设（供设置行区分「上传图片」与「必应壁纸」）。 */
export declare function isCustomPreset(id: string): boolean;
/**
 * 当前值是否为「图片来源型」预设（custom/bing）：背景内容来自 imagePath。
 * 呈现器、特效与 asset 路由只认 imagePath，因此两类来源共用同一条通路。
 * @param id - 设置的 preset 字段值。
 * @returns 是否由 imagePath 提供背景内容。
 */
export declare function isImagePreset(id: string): boolean;
//# sourceMappingURL=presets.d.ts.map