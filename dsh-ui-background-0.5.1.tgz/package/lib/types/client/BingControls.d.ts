import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** 设置行的文案函数类型（子组件复用，避免各自再写一遍 PropsLocale 泛型）。 */
export type BackgroundTranslate = PropsLocale<'settings.background'>['t'];
/** 一次取图的模式。 */
export type BingFetchMode = 'latest' | 'random';
/**
 * 本区块真正需要读取的设置子集。
 *
 * 刻意不收整份 BackgroundSettings：整对象订阅会让本区块在不相关字段（不透明度、
 * 模糊）变化时跟着重渲染，拖动滑块时白白付出渲染成本。
 */
export interface BingSettingsView {
    /** 当前预设 id（判断是否正在显示必应壁纸）。 */
    preset: string;
    /** 当前图片路径（判断是否已有缓存图）。 */
    imagePath: string;
    /** 地区。 */
    bingMarket: string;
    /** 是否取 4K。 */
    bingUhd: boolean;
    /** 是否每日自动更新。 */
    bingAutoRefresh: boolean;
    /** 展示用标题。 */
    bingTitle: string;
    /** 展示用日期。 */
    bingDate: string;
}
/** 区块 props：设置子集 + 四个写操作（全部由 apply 注入，组件零 ctx）。 */
export interface BingControlsProps {
    /** 文案函数。 */
    t: BackgroundTranslate;
    /** 本区块需要的设置子集。 */
    settings: BingSettingsView;
    /** 取一张必应壁纸并应用；失败抛出，由本组件转为提示。 */
    applyBing: (mode: BingFetchMode) => Promise<void>;
    /** 设置地区。 */
    setBingMarket: (market: string) => void;
    /** 设置是否取 4K。 */
    setBingUhd: (enabled: boolean) => void;
    /** 设置是否每日自动更新。 */
    setBingAutoRefresh: (enabled: boolean) => void;
}
/**
 * 渲染必应壁纸区块。
 * @param props - 见 BingControlsProps。
 * @returns 区块元素树。
 */
export declare function BingControls({ t, settings, applyBing, setBingMarket, setBingUhd, setBingAutoRefresh }: BingControlsProps): import("react").JSX.Element;
//# sourceMappingURL=BingControls.d.ts.map