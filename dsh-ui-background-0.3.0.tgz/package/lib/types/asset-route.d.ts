import type { Context } from '@deepseek-ai/cordis';
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
/** 路由参数化配置。 */
export interface BackgroundAssetRouteOptions {
    /** 背景设置的命名空间（从其中读 imagePath）。 */
    namespace: string;
    /** 单张图片字节数上限。 */
    maxBytes: number;
}
/**
 * 创建背景图片资源路由。路由生命周期由调用方（apply 的 effect）管理。
 * @param ctx - 宿主上下文（请求时经 ctx.get('settings') 读配置）。
 * @param options - 命名空间与上限参数。
 * @returns 可直接注册到 ctx.webServer 的 WebRoute。
 */
export declare function createBackgroundAssetRoute(ctx: Context, options: BackgroundAssetRouteOptions): WebRoute;
//# sourceMappingURL=asset-route.d.ts.map