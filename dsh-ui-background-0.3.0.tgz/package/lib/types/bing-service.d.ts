import { type BingMarket } from './background-settings.ts';
/** 壁纸分辨率标记（写入缓存文件名：切换 4K 时两种规格各留一份，互不覆盖）。 */
export type BingResolution = 'UHD' | '1920x1080';
/** 一次取图请求。 */
export interface BingWallpaperRequest {
    /** latest 取最新一张；random 在最近 8 天里随机取（「换一张」）。 */
    mode: 'latest' | 'random';
    /** 地区（白名单外的值回退默认地区）。 */
    market: string;
    /** 是否优先取 4K 原图（该归档没有 4K 时自动回落 1080p）。 */
    uhd: boolean;
    /** 当前已显示的图片路径：random 模式据此避开它（「换一张」必须真的换）。 */
    exclude?: string;
}
/** 取图结果（路由直接作为响应体返回）。 */
export interface BingWallpaper {
    /** 本地缓存文件的绝对路径（交 runtime 持久化到 imagePath）。 */
    path: string;
    /** 展示用日期（YYYY-MM-DD）。 */
    date: string;
    /** 展示用标题。 */
    title: string;
    /** 展示用版权信息。 */
    copyright: string;
    /** 是否为命中缓存（true 表示本次没有下载）。 */
    cached: boolean;
    /** 实际拿到的分辨率。 */
    resolution: BingResolution;
}
/** 服务依赖（全部注入：fetch 可替换，测试无需联网）。 */
export interface BingServiceDeps {
    /** fetch 实现（生产传全局 fetch，测试传桩）。 */
    fetchImpl: typeof fetch;
    /** 缓存目录绝对路径（`$DSH_HOME/ui-background/bing`）。 */
    cacheDir: string;
    /** 单张图片字节上限（与 asset 路由共用，超限的图存了也读不出来）。 */
    maxBytes: number;
    /** 上游超时（毫秒），默认 10s。 */
    timeoutMs?: number;
    /** 归档快照缓存时长（毫秒），默认 10 分钟；测试可设 0 强制每次重取。 */
    archiveTtlMs?: number;
    /** 缓存保留张数，默认 BACKGROUND_BING_KEEP。 */
    keep?: number;
}
/**
 * 归一化地区：白名单外的值（手改 yaml 写错、接口演进）一律回退默认地区，
 * 而不是把任意字符串拼进上游 URL。
 * @param value - 请求或设置里的地区值。
 * @returns 白名单内的地区。
 */
export declare function normalizeMarket(value: string): BingMarket;
/** 必应壁纸服务：进程内单例即可（归档快照与在途请求合并都在实例内维护）。 */
export declare class BingWallpaperService {
    private readonly fetchImpl;
    private readonly cacheDir;
    private readonly maxBytes;
    private readonly timeoutMs;
    private readonly archiveTtlMs;
    private readonly keep;
    /** 归档快照缓存：key 为地区。 */
    private readonly archives;
    /** 在途请求合并：同一请求连点时复用同一个 Promise，不重复下载。 */
    private readonly inFlight;
    /**
     * @param deps - fetch 实现、缓存目录、字节上限与可选超时/保留数。
     */
    constructor(deps: BingServiceDeps);
    /**
     * 取一张必应壁纸（命中缓存则不下载）。
     * @param request - 模式、地区、分辨率与需避开的当前图片。
     * @returns 本地缓存路径与展示元数据。
     * @throws 归档接口不可用、找不到可用图片、或下载/落盘失败。
     */
    fetchWallpaper(request: BingWallpaperRequest): Promise<BingWallpaper>;
    /** 依次尝试候选壁纸；单张失败（缺 4K、图床 404）换下一张，全部失败才抛错。 */
    private resolve;
    /** 确保目标图在本地存在：命中缓存直接返回，否则下载落盘。 */
    private materialize;
    /** 取归档快照：TTL 内复用；接口临时失败时沿用过期快照（界面至少还能显示旧图）。 */
    private archive;
    /** 在缓存目录里找这张图（同一张的不同分辨率各自一份，按文件名前缀精确匹配）。 */
    private findCached;
    /** 下载并落盘（魔数校验 → 先写 .part 再 rename → 按保留数清理旧图）。 */
    private store;
    /** 按保留数清理旧图：文件名以日期开头，字典序即时间序，删掉最旧的超额部分。 */
    private prune;
    /** 下载一张图（超时 + 流式大小上限）。 */
    private download;
}
//# sourceMappingURL=bing-service.d.ts.map