/**
 * dsh-ui-background Node 半边（宿主侧插件入口）。
 *
 * 被宿主 Loader 作为普通 Cordis 插件 import，职责：
 * 1. 注册 `ui-background` 设置命名空间的 schemastery schema（settings 服务的
 *    持久化与校验基础，浏览器半边经同步的 scope 读写同一份文档）；
 * 2. 注册本地图片资源路由（读）、上传路由（写，落盘到 $DSH_HOME/ui-background）
 *    与必应壁纸路由（下载并缓存到 $DSH_HOME/ui-background/bing）。
 * settings / webServer 均为 web 组合中的常驻服务，用 ctx.inject 等待即可。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-10
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-ui-background";
/**
 * 插件激活入口。
 * @param ctx - 宿主 Cordis 上下文。
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map