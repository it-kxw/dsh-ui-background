/**
 * 动态特效渲染器：在背景之上叠加「流光」与「粒子」（共用同一全屏 canvas）。
 *
 * 层级上 canvas 与背景层同级（z-index:-1、pointer-events:none），但插入
 * body 的顺序在背景层之后，因此绘制于背景图之上、AppFrame 内容之下。
 *
 * 关键边界：
 * - 仅当「背景处于激活状态」且「流光/粒子至少一项开启」时才启动
 *   requestAnimationFrame 循环；全关即停，保证零空闲开销。
 * - 尊重系统「减少动态效果」（prefers-reduced-motion）——命中则不启动。
 * - 设备像素比封顶 2、粒子数按视口面积自适应（封顶 160），低配友好。
 * - getContext('2d') 不可用（无 GPU/测试环境）时静默禁用，不抛错。
 * - 生命周期随插件：dispose() 取消动画帧、断开观察器、移除画布。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-11
 */
import type { BackgroundEffectsLike } from './background-runtime.ts';
import { type BackgroundSettings } from '../background-settings.ts';
/** 画布类名（供查询/样式定位）。 */
export declare const EFFECTS_CANVAS_CLASS = "dsh-effects-canvas";
/**
 * 动态特效渲染器。由装配方创建并注入 BackgroundRuntime 的 effects 投影；
 * apply 每个生效设置，dispose 随插件卸载。
 */
export declare class BackgroundEffects implements BackgroundEffectsLike {
    private canvas;
    private ctx;
    private frameRequest;
    private settings;
    private particles;
    private streaks;
    private readonly resizeObserver;
    /** 视口 CSS 尺寸（绘制坐标系；画布物理像素 = 尺寸 × dpr）。 */
    private viewportWidth;
    private viewportHeight;
    /** 是否命中系统「减少动态效果」。 */
    private readonly reducedMotion;
    constructor();
    /**
     * 依最新设置投影特效开关：满足运行条件则启动渲染，否则停止并清屏。
     * @param settings - 生效的背景设置。
     */
    apply(settings: Readonly<BackgroundSettings>): void;
    /**
     * 卸载：取消动画帧、断开观察器、移除画布并释放状态。
     */
    dispose(): void;
    /** 启动渲染循环（幂等）；画布不可用（无 2d 上下文）时静默放弃。 */
    private start;
    /** 停止渲染循环并清屏（幂等；画布保留复用）。 */
    private stop;
    /** 一帧：更新并绘制流光/粒子，续订下一帧。运行时保证互斥；双 true（手改设置）时流光优先。 */
    private tick;
    /** 惰性创建画布并绑定 2d 上下文与尺寸（返回是否可用）。 */
    private ensureCanvas;
    /** 依视口与 DPR 重设画布物理尺寸；粒子分布随视口重建。 */
    private resizeCanvas;
    /** 是否深色配色：主题呈现器在 body 打 `data-ds-dark-theme` 标记；每帧读取开销可忽略。 */
    private isDarkScheme;
    /** 生成或重建粒子（覆盖当前视口，数量按面积自适应；明显度参数：更大、更亮、更快）。 */
    private ensureParticles;
    /**
     * 生成或重建流光条（六条窄亮光带）。
     * 参数取向：半长仅占视口 9%~22%，配合 0.55~0.85 的基准 alpha 与高亮核心。
     * （旧参数是半长 30%~70% 视口、峰值 alpha 0.22 的巨型柔光带，逐像素亮度差
     * 穿过 45% 半透明底衬后不足 0.06，实测肉眼几乎不可见。）
     */
    private ensureStreaks;
    /**
     * 绘制六条斜向漂移的流光。
     * 深色配色走加色混合（'lighter'）形成真正的发光；浅色配色下加色会把光带推成
     * 白色糊在浅底上，故保持普通混合、用深蓝灰实色描边。
     */
    private drawStreaks;
    /** 绘制单条流光：外圈光晕 + 内圈高亮核心（同一位置两段同向渐变）。 */
    private drawStreak;
    /** 以当前变换原点为中心画一条水平渐隐光带（两端 alpha 归零，避免硬边）。 */
    private paintBand;
    /** 绘制漂浮粒子（上浮 + 横向摆动，呼吸明显；颜色随配色适配）。 */
    private drawParticles;
}
//# sourceMappingURL=effects-renderer.d.ts.map