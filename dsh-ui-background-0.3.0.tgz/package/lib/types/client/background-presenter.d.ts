/**
 * 背景 DOM 呈现器：把生效的设置投影到文档，纯 DOM 写入，无 React 参与。
 *
 * 职责（对齐 ThemePresenter 的"只回收自己写的东西"模式）：
 * - 惰性创建并挂载背景层 `<div class="dsh-bg-layer">`（body 直接子节点）。
 * - 背景激活时给 body 打 `data-dsh-bg-active`（CSS 依此让出 AppFrame 的
 *   语义底色），并把背景值写成层的内联 CSS 变量（变量作用域天然限在层内）。
 * - 未激活或卸载时撤回 attribute、移除层、清空变量，界面回到 DSH 原样。
 * 配色切换完全交给 CSS 的 `body[data-ds-dark-theme]` 选择器，本类不感知。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-10
 */
import { type BackgroundSettings } from '../background-settings.ts';
/** body 上的背景激活标记（background.css 据此透明化 --dsw-alias-bg-base）。 */
export declare const BG_ACTIVE_ATTRIBUTE = "data-dsh-bg-active";
/** 解析后的背景值：每个配色一套 CSS background-image 值。 */
export interface BackgroundValues {
    /** 浅色配色背景图。 */
    light: string;
    /** 深色配色背景图。 */
    dark: string;
}
/**
 * 从生效设置解析背景值；无背景（'none'、未知预设、图片来源型预设缺图片）返回 null。
 * 模块级纯函数便于单独测试。
 * @param settings - 生效的背景设置。
 * @returns 两套配色的 background-image 值，或 null（不激活背景）。
 */
export declare function backgroundValues(settings: Readonly<BackgroundSettings>): BackgroundValues | null;
/** 背景层元素类型（jsdom/浏览器一致的 DOM 接口）。 */
export type BackgroundLayerElement = HTMLDivElement;
/**
 * 投影生效设置到 DOM。
 * @param settings - 生效的设置快照（每次 publish 重算）。
 */
export declare class BackgroundPresenter {
    /** 已挂载的背景层；undefined 表示尚未创建或非浏览器环境。 */
    private layer;
    /** 上一次写入层的变量名（重写前先撤回）。 */
    private applied;
    /**
     * 应用一份设置到 DOM：激活时建层+写变量，非激活时撤回全部痕迹。
     * @param settings - 生效的背景设置。
     */
    apply(settings: Readonly<BackgroundSettings>): void;
    /**
     * 卸载：移除背景层、撤回 body 标记。幂等。
     */
    dispose(): void;
    /** 找到已挂载的背景层，否则创建并追加到 body。 */
    private ensureLayer;
    /** 撤回层上的内联变量；层不存在时（非浏览器）为无操作。 */
    private clearLayer;
}
//# sourceMappingURL=background-presenter.d.ts.map