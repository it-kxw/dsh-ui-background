/** 一次取图请求。 */
export interface BingWallpaperQuery {
    /** latest 取最新一张（进入界面/首次选择）；random 换一张。 */
    mode: 'latest' | 'random';
    /** 地区（BING_MARKETS 之一）。 */
    market: string;
    /** 是否取 4K 原图。 */
    uhd: boolean;
}
/** 取图结果（服务端已落盘，path 为本地绝对路径）。 */
export interface BingWallpaperResult {
    /** 本地缓存文件绝对路径。 */
    path: string;
    /** 展示用日期（YYYY-MM-DD）。 */
    date: string;
    /** 展示用标题。 */
    title: string;
    /** 展示用版权信息。 */
    copyright: string;
    /** 是否为命中缓存（未重新下载）。 */
    cached: boolean;
    /** 实际拿到的分辨率标记。 */
    resolution: string;
}
/**
 * 取一张必应壁纸。
 * @param query - 模式、地区与分辨率偏好。
 * @returns 本地缓存路径与展示元数据。
 * @throws 网络失败/超时、非 2xx 响应、或响应缺少可用路径。
 */
export declare function requestBingWallpaper(query: BingWallpaperQuery): Promise<BingWallpaperResult>;
//# sourceMappingURL=bing.d.ts.map