/**
 * dsh-ui-background 浏览器半边（dsh.client 插件入口）。
 *
 * apply 把阶段 1+2 的模块装配为两个 UI 入口：
 * 1. `settings.general.item` 的「背景」设置行；
 * 2. `shell.overlay` 的一键切换悬浮按钮。
 * 两个注册项共享同一个 store 工厂（renderer 各自创建实例，因此 apply 维护
 * 两个 bound，sync 全部同步）；store 是运行时快照的镜像，写入永远走
 * BackgroundRuntime 的 set* 入口。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-10
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type BackgroundLocaleKey } from './locales.ts';
export type { BackgroundRowComponentProps, BackgroundRowInjected } from './BackgroundRow.tsx';
export type { BackgroundQuickToggleComponentProps, BackgroundQuickToggleInjected } from './BackgroundQuickToggle.tsx';
export type { BackgroundLocaleKey } from './locales.ts';
export type { BackgroundSettings } from '../background-settings.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** 背景功能的所有文案。 */
        'settings.background': BackgroundLocaleKey;
    }
}
/** 本插件拥有的 locale 命名空间。 */
export declare const NS = "settings.background";
/** 依赖的服务：slots/locale/remote/settingsScope（remote 供 settingsScope 转发的失效订阅）。 */
export declare const inject: string[];
/**
 * 浏览器插件激活：装配运行时、dict 与两个 UI 入口。
 * @param ctx - 浏览器 Cordis 上下文。
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map