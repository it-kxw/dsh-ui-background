/** 一次上传的结果：落盘路径与像素尺寸。 */
export interface UploadedBackgroundImage {
    /** 服务端落盘的绝对路径（交 runtime.setImagePath 持久化）。 */
    path: string;
    /** 图片像素宽。 */
    width: number;
    /** 图片像素高。 */
    height: number;
}
/**
 * 读取一张图片的像素尺寸（createImageBitmap 优先，objectURL+Image 兜底）。
 * @param source - 可作为图片源的 Blob 或 URL。
 * @returns 像素宽高；读不到时 width/height 为 0。
 */
export declare function readImageSize(source: Blob | string): Promise<{
    width: number;
    height: number;
}>;
/**
 * 上传一个本地图片文件：预检扩展名与大小、验证有效性、读取尺寸、POST 到上传路由。
 * @param file - 用户选择的文件。
 * @returns 落盘路径与像素尺寸。
 * @throws 扩展名不在白名单、文件超过大小上限、上传接口拒绝、或文件不是有效图片。
 */
export declare function uploadBackgroundImage(file: File): Promise<UploadedBackgroundImage>;
//# sourceMappingURL=upload.d.ts.map