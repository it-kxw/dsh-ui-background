/**
 * `settings.background` 命名空间字典（简体中文为源，英文补齐同键集）。
 * 预设标签也归类于此：预设表只存稳定 id，文案经 locale key 解析，
 * 保证切换语言时预设名跟随界面（对齐 DSH 的 locale-owned 规则）。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-10
 */
/** 简体中文词典（键集之源）。 */
export declare const zh: {
    'row.title': string;
    'row.opacity': string;
    'row.blur': string;
    'row.fill': string;
    'row.fill.cover': string;
    'row.fill.contain': string;
    'row.fill.tile': string;
    'row.clear': string;
    'row.customImage': string;
    'row.upload': string;
    'row.uploading': string;
    'row.uploadError': string;
    'row.ratio': string;
    'row.streaks': string;
    'row.particles': string;
    'row.effect.off': string;
    'row.bing': string;
    'row.bing.get': string;
    'row.bing.next': string;
    'row.bing.loading': string;
    'row.bing.error': string;
    'row.bing.info': string;
    'row.bing.market': string;
    'row.bing.uhd': string;
    'row.bing.auto': string;
    'preset.none': string;
    'preset.aurora': string;
    'preset.sunset': string;
    'preset.emerald': string;
    'preset.midnight': string;
    'preset.sand': string;
    'preset.slate': string;
    'toggle.label': string;
    'toggle.next': string;
};
/** 设置命名空间的 key 联合（组件 t 的键域）。 */
export type BackgroundLocaleKey = keyof typeof zh;
/** 英文词典：与 zh 键集一一对应。 */
export declare const en: {
    'row.title': string;
    'row.opacity': string;
    'row.blur': string;
    'row.fill': string;
    'row.fill.cover': string;
    'row.fill.contain': string;
    'row.fill.tile': string;
    'row.clear': string;
    'row.customImage': string;
    'row.upload': string;
    'row.uploading': string;
    'row.uploadError': string;
    'row.ratio': string;
    'row.streaks': string;
    'row.particles': string;
    'row.effect.off': string;
    'row.bing': string;
    'row.bing.get': string;
    'row.bing.next': string;
    'row.bing.loading': string;
    'row.bing.error': string;
    'row.bing.info': string;
    'row.bing.market': string;
    'row.bing.uhd': string;
    'row.bing.auto': string;
    'preset.none': string;
    'preset.aurora': string;
    'preset.sunset': string;
    'preset.emerald': string;
    'preset.midnight': string;
    'preset.sand': string;
    'preset.slate': string;
    'toggle.label': string;
    'toggle.next': string;
};
//# sourceMappingURL=locales.d.ts.map