import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import { type BackgroundSettings } from '../background-settings.ts';
/** 设置行的文案函数类型（子组件复用，避免各自再写一遍 PropsLocale 泛型）。 */
export type BackgroundTranslate = PropsLocale<'settings.background'>['t'];
/** 一次取图的模式。 */
export type BingFetchMode = 'latest' | 'random';
/** 区块 props：设置快照 + 四个写操作（全部由 apply 注入，组件零 ctx）。 */
export interface BingControlsProps {
    /** 文案函数。 */
    t: BackgroundTranslate;
    /** 当前生效设置。 */
    settings: Readonly<BackgroundSettings>;
    /** 取一张必应壁纸并应用；失败抛出，由本组件转为提示。 */
    applyBing: (mode: BingFetchMode) => Promise<void>;
    /** 设置地区。 */
    setBingMarket: (market: string) => void;
    /** 设置是否取 4K。 */
    setBingUhd: (enabled: boolean) => void;
    /** 设置是否每日自动更新。 */
    setBingAutoRefresh: (enabled: boolean) => void;
}
/**
 * 渲染必应壁纸区块。
 * @param props - 见 BingControlsProps。
 * @returns 区块元素树。
 */
export declare function BingControls({ t, settings, applyBing, setBingMarket, setBingUhd, setBingAutoRefresh }: BingControlsProps): import("react").JSX.Element;
//# sourceMappingURL=BingControls.d.ts.map