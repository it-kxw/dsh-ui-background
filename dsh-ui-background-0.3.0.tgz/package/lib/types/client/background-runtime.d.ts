/**
 * 背景状态运行时：设置命名空间读写、revision 快照与订阅的单一事实源。
 *
 * 设计对齐 ui-theme 的 ThemeRuntime：
 * - 写操作只有 set* 一组入口，每个入口校验参数、经 host scope 持久化、发布快照；
 * - host 发布的变更经 adopt() 吸收（不写回），浏览器与其它标签页的写入得以同步；
 * - 发布时把快照投影给呈现器（DOM），并通知订阅者（UI store 同步用）。
 * 不持有 ctx：生命周期（host 订阅、卸载）由装配方（apply）负责。
 *
 * @author 康小汪【kxw】
 * @date 2026-09-10
 */
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import { type BackgroundFill, type BackgroundSettings } from '../background-settings.ts';
import type { BackgroundPresenter } from './background-presenter.ts';
/** 一次发布的不可变状态快照（uSES 安全：变化之间引用稳定）。 */
export interface BackgroundSnapshot {
    /** 当前生效的设置。 */
    readonly settings: Readonly<BackgroundSettings>;
    /** 单调递增的变更计数。 */
    readonly revision: number;
}
/**
 * 需要随必应壁纸一并持久化的部分（服务端返回结果里与展示/渲染相关的字段）。
 * 刻意不复用 client/bing.ts 的结果类型：运行时不该依赖取图模块（低耦合）。
 */
export interface BingWallpaperInput {
    /** 服务端落盘的本地绝对路径。 */
    path: string;
    /** 展示用标题。 */
    title: string;
    /** 展示用日期（YYYY-MM-DD）。 */
    date: string;
    /** 展示用版权信息。 */
    copyright: string;
}
/**
 * 动态特效投影目标：每次发布与 presenter 平级调用；由特效渲染器
 * （BackgroundEffects）实现，装配方负责其 dispose 生命周期。
 */
export interface BackgroundEffectsLike {
    /** 依最新设置投影特效开关；未开启时回收特效。 */
    apply(settings: Readonly<BackgroundSettings>): void;
    /** 卸载清理（取消动画帧、移除画布）。 */
    dispose(): void;
}
/**
 * 背景设置的运行时。
 *
 * 连续写（滑杆拖动）时只即时更新本地状态并发布（DOM/UI 立即响应），
 * 持久化走 200ms 尾沿防抖：停顿后才把最新值写入 host，避免每一档都触发
 * 一次设置 RPC + YAML 落盘（高频拖动会串行堆积导致卡顿）。
 *
 * @param host - 装配方 bind 的同名设置 scope。
 * @param presenter - 负责背景 DOM 投影的呈现器。
 * @param effects - 可选的动态特效投影目标（与 presenter 平级；缺省时跳过）。
 */
export declare class BackgroundRuntime {
    private readonly host;
    private readonly presenter;
    private readonly effects?;
    /** 当前生效设置（adopt 或写操作后更新）。 */
    private settings;
    private revision;
    private snapshot;
    private readonly listeners;
    /** 持久化防抖计时器（值为 undefined 表示当前无待写）。 */
    private persistTimer;
    /** 待持久化的字段写（按字段合并：同字段只留最新，不同字段各自落盘）。 */
    private readonly pendingWrites;
    constructor(host: SettingsScope<BackgroundSettings>, presenter: BackgroundPresenter, effects?: BackgroundEffectsLike | undefined);
    /**
     * 读当前不可变快照（引用稳定，uSES 安全）。
     * @returns 当前快照。
     */
    getSnapshot(): BackgroundSnapshot;
    /**
     * 订阅快照变更。
     * @param listener - 每次发布后的回调。
     * @returns 取消订阅函数。
     */
    subscribe(listener: () => void): () => void;
    /**
     * 吸收 host 已接受的 section（不写回）。装配方在 host.subscribe 里调用。
     */
    adopt(): void;
    /**
     * 切换背景预设（唯一入口）。
     * @param id - 内置预设 id、'none'（清除）或图片来源型预设（'custom'/'bing'，
     *   后者的图片由 setImagePath/setBing 一并写入）。
     * @throws 未知预设 id（非 none、非图片来源型、也不在预设表）。
     */
    setPreset(id: string): void;
    /**
     * 设置不透明度。
     * @param value - BACKGROUND_OPACITY_MIN..MAX 的有限值。
     * @throws 越界或非有限值。
     */
    setOpacity(value: number): void;
    /**
     * 设置背景模糊半径。
     * @param value - BACKGROUND_BLUR_MIN..MAX 的整数 px。
     * @throws 越界或非整数。
     */
    setBlur(value: number): void;
    /**
     * 设置图片填充方式。
     * @param value - 填充方式枚举之一。
     * @throws 未知枚举值。
     */
    setFill(value: BackgroundFill): void;
    /**
     * 设置自定义图片路径；非空时同时把 preset 置为 'custom'，空串仅清除图片。
     *
     * 与其它字段不同，这里**先持久化再发布**：自定义图片的背景 URL 需要服务端
     * asset 路由按已落盘的设置授权，若先发布再异步持久化，首帧图片请求会命中
     * 旧设置返回 404，背景图不加载（"点击没反应"）。等待 host.set 落定后再
     * 发布，首次请求即为有效授权。持久化失败则抛错且不产生半状态。
     * @param path - 本地图片绝对路径（trim 后存储）。
     * @returns 持久化与发布的完成信号（调用方 fire-and-forget 时用 void 包裹）。
     */
    setImagePath(path: string): Promise<void>;
    /**
     * 应用一张必应壁纸：先持久化（图片路径 + preset + 展示元数据）再发布。
     *
     * 与 setImagePath 同因：背景 URL 需要服务端 asset 路由按已落盘的 imagePath
     * 授权，若先发布再异步持久化，首帧图片请求会命中旧设置返回 404（"没反应"）。
     * 五笔写走一次原子 mutate（同一 revision）：既省往返，也避免出现"已是必应图
     * 但 preset 还没切换"的中间态快照（会闪一下无背景）。
     * @param wallpaper - 服务端返回的缓存路径与展示元数据。
     * @throws 路径为空（服务端契约破坏时不写入任何字段）。
     */
    setBing(wallpaper: BingWallpaperInput): Promise<void>;
    /**
     * 设置必应壁纸地区（决定壁纸池与标题语言；下一次取图生效）。
     * @param value - BING_MARKETS 白名单之一。
     * @throws 不在白名单内的地区值。
     */
    setBingMarket(value: string): void;
    /**
     * 设置必应壁纸是否取 4K 原图（切换后两种规格各留一份缓存，互不覆盖）。
     * @param enabled - true 取 UHD，false 取接口给出的 1920×1080。
     * @throws 非布尔值。
     */
    setBingUhd(enabled: boolean): void;
    /**
     * 设置是否在进入界面时自动对齐「今日」壁纸。
     * @param enabled - true 开启（命中缓存则零下载）。
     * @throws 非布尔值。
     */
    setBingAutoRefresh(enabled: boolean): void;
    /**
     * 切换动态流光特效（与粒子互斥：开启流光会同时关闭粒子）。
     * @param enabled - true 开启、false 关闭。
     * @throws 非布尔值。
     */
    setStreaks(enabled: boolean): void;
    /**
     * 切换粒子特效（与流光互斥：开启粒子会同时关闭流光）。
     * @param enabled - true 开启、false 关闭。
     * @throws 非布尔值。
     */
    setParticles(enabled: boolean): void;
    /** 发布新快照：投影到背景呈现器与特效渲染器、递增 revision、通知订阅者。 */
    private publish;
    /**
     * 安排一笔持久化写（尾沿防抖）：按字段合并，停顿后把待写字段一并落盘。
     * @param field - 设置字段。
     * @param value - 字段值。
     */
    private schedulePersist;
    /**
     * 立即落盘全部待写字段并清空计时器（卸载冲刷用）。幂等。
     */
    flushPersist(): void;
    /**
     * 卸载：冲刷未落盘的防抖写（避免最后一笔设置丢失）。
     */
    dispose(): void;
}
//# sourceMappingURL=background-runtime.d.ts.map