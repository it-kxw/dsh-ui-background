import type { Context } from '@deepseek-ai/cordis';
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
import { type BingWallpaperService } from './bing-service.ts';
/** 路由参数化配置。 */
export interface BackgroundBingRouteOptions {
    /** 背景设置命名空间（读取必应默认值与当前图片）。 */
    namespace: string;
    /** 必应壁纸服务（由 apply 注入，测试可传桩）。 */
    service: BingWallpaperService;
}
/**
 * 创建必应壁纸路由。路由生命周期由调用方（apply 的 effect）管理。
 * @param ctx - 宿主上下文（请求时经 ctx.get('settings') 读默认值与当前图片）。
 * @param options - 命名空间与服务实例。
 * @returns 可直接注册到 ctx.webServer 的 WebRoute。
 */
export declare function createBackgroundBingRoute(ctx: Context, options: BackgroundBingRouteOptions): WebRoute;
//# sourceMappingURL=bing-route.d.ts.map