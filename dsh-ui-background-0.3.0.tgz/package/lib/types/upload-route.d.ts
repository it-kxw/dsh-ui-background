import type { Context } from '@deepseek-ai/cordis';
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver';
/** 上传路由参数化配置。 */
export interface BackgroundUploadRouteOptions {
    /** 背景设置的命名空间（从其中读旧 imagePath 以清理旧上传）。 */
    namespace: string;
    /** 单张图片字节数上限。 */
    maxBytes: number;
    /** 上传落盘目录（绝对路径，由调用方从 dshHomePath('ui-background') 解析）。 */
    uploadDir: string;
}
/**
 * 创建图片上传路由。路由生命周期由调用方（apply 的 effect）管理。
 * @param ctx - 宿主上下文（请求时经 ctx.get('settings') 读旧路径）。
 * @param options - 命名空间、上限与落盘目录参数。
 * @returns 可直接注册到 ctx.webServer 的 WebRoute。
 */
export declare function createBackgroundUploadRoute(ctx: Context, options: BackgroundUploadRouteOptions): WebRoute;
//# sourceMappingURL=upload-route.d.ts.map